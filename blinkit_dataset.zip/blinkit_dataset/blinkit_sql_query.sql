


-- 1. Inventory Risk Detection
-- Find all products where the available stock (stock_received - damaged_stock)
-- is below min_stock 
-- and calculate the reorder quantity required to reach max_stock_level.
-- Rank products by highest reorder quantity.

with stock as (
select  n.product_id,
		p.product_name,
		p.category,
		p.min_stock_level as min,
		p.max_stock_level as max,
		(n.stock_received + o.stock_received) as stock_received,
		(n.damaged_stock + o.damaged_stock) as damaged_stock
from new_inventory as n
join old_inventory as o
on n.product_id = o.product_id
join products as p
on n.product_id = p.product_id 
group by n.product_id, p.product_name, p.min_stock_level,
		 p.max_stock_level, p.category,
		(n.stock_received + o.stock_received),
		(n.damaged_stock + o.damaged_stock)
		
),
available_stock as (
		select product_id, stock_received,damaged_stock, 
		(stock_received - damaged_stock) as available_stock
		from stock
),
inventory_risk as (
		select  s.product_id,
				s.product_name,
				s.category,
				s.min,
				s.max,
				s.stock_received,
				s.damaged_stock,
				a.available_stock, 
			(s.max - available_stock) as reorder_quantity
from stock as s
join available_stock as a
on s.product_id = a.product_id 
where a.available_stock <= s.min
)
select *,
	dense_rank() 
		over(order by 
			reorder_quantity desc ) as reorder_rank
	from inventory_risk





-- 2. Dead Stock Identification
-- Find products that were received into inventory but never appeared in any order.
-- Return product_id, product_name, category, total received stock,
-- and damaged stock.
select  p.product_id,
		p.product_name,
		p.category,
	    (n.stock_received + o.stock_received) as total_received_stock,
		(n.damaged_stock + o.damaged_stock) as damaged_stock
from products as p 
left join new_inventory as n
on p.product_id = n.product_id 
left join old_inventory as o
on p.product_id = o.product_id 
where not exists (
		select oi.product_id 
		from order_items as oi 
		where p.product_id = oi.product_id 
)
group by p.product_id, p.product_name, p.category,
	   (n.stock_received + o.stock_received),
	   (n.damaged_stock + o.damaged_stock)


SELECT
    COUNT(*) AS total_products,
    COUNT(*) FILTER (
        WHERE EXISTS (
            SELECT 1
            FROM order_items oi
            WHERE oi.product_id = p.product_id
        )
    ) AS sold_products
FROM products p;


-- 3. Customer Purchase Ranking
-- For each customer, calculate their total spending, 
-- number of orders, and average order value.
-- Rank customers within each customer_type using DENSE_RANK(). 
-- Return only the top 3 customers from each customer type.

with customer_summary as(
select  c.customer_id,
		c.customer_name,
		count(o.customer_id) as number_of_orders,
		round(avg(o.order_total),2) as avg_order_value,
		c.customer_segment as customer_type 
from customers as c 
join orders as o
on c.customer_id = o.customer_id
group by c.customer_id, c.customer_name, c.customer_segment

),
ranked_customers as (
	select *, 
	dense_rank() over(
					partition by customer_type
					order by avg_order_value desc 
					) as ranked 
					from customer_summary 
)
select * from ranked_customers 
where ranked <= 3




-- 4. Repeat Purchase Analysis
-- Identify customers who purchased the same product at least 3 different times.
-- Return customer, product, purchase count, first purchase date,
-- and most recent purchase date.

SELECT  c.customer_id, 
		c.customer_name,
		p.product_name,
		oi.order_id, 
		COUNT(DISTINCT oi.product_id) AS product_frequency,
		MIN(order_date) AS first_purchase_date,
		MAX(order_date) AS most_recent_purchase_date
FROM customers AS c
INNER JOIN orders AS o
ON c.customer_id = o.customer_id
INNER JOIN order_items AS oi
ON oi.order_id = o.order_id 
INNER JOIN products AS p
ON oi.product_id = p.product_id  
GROUP BY  c.customer_id,
		 c.customer_name, 
		 p.product_name,
		 oi.order_id
-- HAVING COUNT(DISTINCT oi.product_id)<=3
ORDER BY product_frequency DESC





-- 5. Revenue vs Order Total Validation
-- Calculate order revenue from order_items using:
-- quantity × unit_price
-- Compare it with orders.order_total. 
-- Identify orders where the calculated amount differs 
-- from order_total by more than 5%.




















select * from products 
select * from orders 
select * from order_items 
select * from marketing_performance
select * from new_inventory 
select * from old_inventory
select * from delivery_performance
select * from customers 
select * from customer_feedback 










-- 6. Late Delivery Impact
-- Find the top 10 stores with the highest late-delivery rate. Calculate:
-- Total orders
-- Late orders
-- Late delivery %
-- Average delivery delay
-- Average order value

-- 7. Customer Churn Signal
-- Identify customers whose latest order value is at least 30% lower than their previous order value. Use LAG() and return the customers latest order, previous order, and percentage decrease.
-- 8. Product Revenue Ranking by Category
-- Calculate total revenue for every product and rank products within their category using RANK(). Return products whose revenue is within the top 10% of their category.

-- 9. Marketing Campaign Efficiency
-- Calculate campaign-level:

-- CTR = clicks / impressions
-- Conversion Rate = conversions / clicks
-- CPC = spend / clicks
-- CPA = spend / conversions
-- ROAS = revenue_generated / spend

-- Then identify campaigns with ROAS above the average ROAS of their channel.

-- 10. Sentiment vs Rating Anomaly
-- Find feedback records where:

-- Rating ≤ 2 but sentiment = Positive, OR
-- Rating ≥ 4 but sentiment = Negative.

-- Calculate the percentage of anomalous feedback for each feedback category.

-- 11. Most Valuable Customers by Recent Activity
-- Find customers whose total spending is above the overall customer average, but whose last order occurred within the latest 30 days of the dataset. Rank them by total revenue.

-- 12. Stock Turnover Analysis
-- Calculate product-level stock turnover:

-- Total Quantity Sold / Net Stock Received

-- Identify the top 10 products with the highest turnover and compare their turnover against the average turnover of their category.

-- 13. Consecutive Late Deliveries
-- Identify customers who experienced late deliveries on 3 or more consecutive orders. Use window functions such as LAG() to detect the consecutive pattern.

-- 14. First vs Repeat Order Revenue
-- Divide every customers orders into:

-- First order
-- Second order
-- Third order
-- Repeat orders

-- Calculate the total revenue and average order value for each order number using ROW_NUMBER().

-- 15. Ultimate Multi-Table Business Challenge 🧠
-- Identify high-value customers at risk of churn who satisfy all of these conditions:
-- Customer's total spending is above the overall average.
-- Their latest order value is at least 25% lower than their previous order.
-- Their average feedback rating is below 3.5.
-- At least 30% of their orders were delayed.
-- Their most frequently purchased product is currently below minimum stock level.













